"""OpenLine Wallet local test source."""
